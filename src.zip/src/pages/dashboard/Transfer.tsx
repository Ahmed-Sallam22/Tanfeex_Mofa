import SearchBar from "@/shared/SearchBar";
import { SharedTable } from "@/shared/SharedTable";
import type { TableColumn, TableRow } from "@/shared/SharedTable";
import { SharedModal } from "@/shared/SharedModal";
import { SharedSelect } from "@/shared/SharedSelect";
import type { SelectOption } from "@/shared/SharedSelect";
import { RichTextEditor } from "@/components/ui";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { useTranslation } from "react-i18next";
import {
  useGetTransferListQuery,
  useCreateTransferMutation,
  useUpdateTransferMutation,
  useDeleteTransferMutation,
  useGetTransferStatusQuery,
  useGetOracleStatusQuery,
} from "@/api/transfer.api";
import type { TransferItem } from "@/api/transfer.api";
import {
  useGetAttachmentsQuery,
  useUploadAttachmentMutation,
} from "@/api/attachments.api";
import type { Attachment } from "@/api/attachments.api";

export default function Transfer() {
  const { t } = useTranslation();
  const navigate = useNavigate();

  // State management
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [selectedTransfer, setSelectedTransfer] = useState<TransferItem | null>(
    null
  );
  const [time_period, settime_period] = useState<string>("");
  const [reason, setreason] = useState<string>("");
  const [budget_control, setBudgetControl] = useState<string>("");
  const [transfer_type, setTransferType] = useState<string>("");
  const [allocation_sub_type, setAllocationSubType] = useState<string>("");

  // Attachments state
  const [isAttachmentsModalOpen, setIsAttachmentsModalOpen] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] =
    useState<string>("");

  // Status pipeline modal state
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [statusTransactionId, setStatusTransactionId] = useState<number | null>(
    null
  );

  // Selection state for export
  const [selectedRows, setSelectedRows] = useState<Set<number | string>>(
    new Set()
  );
  const [showExportUI, setShowExportUI] = useState(false);

  // Validation states
  const [validationErrors, setValidationErrors] = useState<{
    time_period?: string;
    reason?: string;
    budget_control?: string;
    transfer_type?: string;
    allocation_sub_type?: string;
  }>({});

  // API calls
  const {
    data: transferResponse,
    isLoading,
    error,
  } = useGetTransferListQuery({
    page: currentPage,
    page_size: 10,
    code: "FAR",
  });

  const [createTransfer, { isLoading: isCreating }] =
    useCreateTransferMutation();
  const [updateTransfer, { isLoading: isUpdating }] =
    useUpdateTransferMutation();
  const [deleteTransfer] = useDeleteTransferMutation();

  // Attachments API calls
  const {
    data: attachmentsData,
    isLoading: isLoadingAttachments,
    refetch: refetchAttachments,
  } = useGetAttachmentsQuery(selectedTransactionId, {
    skip: !selectedTransactionId || !isAttachmentsModalOpen,
  });

  const [uploadAttachment, { isLoading: isUploading }] =
    useUploadAttachmentMutation();

  // State for managing edit mode opening
  const [shouldOpenModal, setShouldOpenModal] = useState(false);

  // Effect to open modal after state updates are complete
  useEffect(() => {
    if (shouldOpenModal && isEditMode) {
      console.log("🚀 Opening modal with state:", { time_period, reason });
      setIsCreateModalOpen(true);
      setShouldOpenModal(false);
    }
  }, [shouldOpenModal, isEditMode, time_period, reason]);

  // Handle null/empty values
  const safeValue = (value: unknown, fallback: string = "-") => {
    if (value === null || value === undefined || value === "") {
      return fallback;
    }
    return String(value);
  };

  // Helper function to convert plain text to basic HTML (kept for potential future use)
  // const textToHtml = (text: string): string => {
  //   if (!text) return '';
  //   const lines = text.split('\n').filter(line => line.trim() !== '');
  //   if (lines.length === 0) return '';
  //   if (lines.length === 1) return `<p>${lines[0]}</p>`;
  //   return lines.map(line => `<p>${line}</p>`).join('');
  // };

  // Transform API data to table format
  const transformedData: TableRow[] =
    transferResponse?.results?.map((item: TransferItem) => ({
      id: item.transaction_id,
      code: safeValue(item.code),
      requested_by: safeValue(item.requested_by),
      description: safeValue(item.notes, t("common.noData")),
      request_date: item.request_date
        ? new Date(item.request_date).toLocaleDateString()
        : "-",
      transaction_date: safeValue(item.transaction_date, t("common.noData")),
      track: item.transaction_id,
      status: safeValue(item.status, t("common.pending")),
      attachment: item.attachment,
      amount: item.amount || 0,
      // Include original item for detail view
      original: item,
    })) || [];

  // Table columns configuration
  const transferColumns: TableColumn[] = [
    {
      id: "code",
      header: t("tableColumns.code"),
      accessor: "code",
      render: (value, row) => (
        <span
          className="font-medium bg-[#F6F6F6] p-2  rounded-md cursor-pointer hover:bg-[#e8f2ef] transition"
          onClick={() => handleCodeClick(row)}
        >
          {safeValue(value)}
        </span>
      ),
    },
    {
      id: "requested_by",
      header: t("tableColumns.requestedBy"),
      accessor: "requested_by",
      render: (value) => (
        <span className="font-medium text-[#282828]">{safeValue(value)}</span>
      ),
    },
    {
      id: "description",
      header: t("tableColumns.description"),
      accessor: "description",
      render: (value) => (
        <div
          className="text-[#282828] max-w-xs prose prose-sm prose-p:my-1 prose-p:leading-5"
          dangerouslySetInnerHTML={{
            __html: safeValue(value, t("common.noData")),
          }}
          style={{
            wordBreak: "break-word",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        />
      ),
    },
    {
      id: "request_date",
      header: t("tableColumns.requestDate"),
      accessor: "request_date",
      render: (value) => (
        <span className="text-[#282828]">{safeValue(value)}</span>
      ),
    },
    {
      id: "transaction_date",
      header: t("tableColumns.transactionDate"),
      accessor: "transaction_date",
      render: (value) => (
        <span className="text-[#282828]">
          {safeValue(value, t("common.noData"))}
        </span>
      ),
    },
    {
      id: "track",
      header: t("tableColumns.actions"),
      accessor: "track",
      render: (_value, row) => (
        <span
          className="font-medium bg-[#F6F6F6] p-2 rounded-md cursor-pointer hover:bg-[#e8f2ef] transition"
          onClick={() => handleTrackClick(row)}
        >
          {t("common.view")}
        </span>
      ),
    },
    {
      id: "status",
      header: t("tableColumns.status"),
      accessor: "status",
      render: (value, row) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer hover:opacity-80 transition ${
            value === "approved" || value === "active"
              ? "bg-green-100 text-green-800"
              : value === "pending"
              ? "bg-yellow-100 text-yellow-800"
              : value === "rejected"
              ? "bg-red-100 text-red-800"
              : value === "in_progress"
              ? "bg-blue-300 text-blue-800"
              : "bg-gray-100 text-gray-800"
          }`}
          onClick={() => handleStatusClick(row)}
        >
          {safeValue(value).charAt(0).toUpperCase() + safeValue(value).slice(1)}
        </span>
      ),
    },
    {
      id: "attachment",
      header: t("common.attachments"),
      accessor: "attachment",
      render: (_value, row) => (
        <span
          className="font-medium bg-[#F6F6F6] p-2 rounded-md cursor-pointer hover:bg-[#e8f2ef] transition"
          onClick={() => handleAttachmentsClick(row)}
        >
          {t("common.attachments")}
        </span>
      ),
    },
  ];

  // Event handlers
  const handleCodeClick = (row: TableRow) => {
    const originalTransfer = row.original as TransferItem;
    const status = originalTransfer.status || "pending";
    navigate(`/app/transfer/${row.id}`, {
      state: { status },
    });
  };

  const handleStatusClick = (row: TableRow) => {
    const transactionId = Number(row.id);
    // Clear any previous status data to prevent showing old data
    setStatusTransactionId(null);
    setIsStatusModalOpen(true);
    // Set the transaction ID after modal is open to trigger fresh API call
    setTimeout(() => {
      setStatusTransactionId(transactionId);
    }, 100);
    console.log("Opening status pipeline for transaction:", transactionId);
  };

  // Handler for attachments click
  const handleAttachmentsClick = (row: TableRow) => {
    const transactionId = String(row.id);
    setSelectedTransactionId(transactionId);
    setIsAttachmentsModalOpen(true);
    console.log("Opening attachments modal for transaction:", transactionId);
  };
  // File upload handlers
  const handleFileSelect = async (file: File) => {
    if (!selectedTransactionId) {
      toast.error(t("messages.noTransactionSelected"));
      return;
    }

    try {
      await uploadAttachment({
        transaction_id: selectedTransactionId,
        file: file,
      }).unwrap();

      toast.success(t("messages.uploadSuccess"));
      // Refresh the attachments list
      refetchAttachments();
    } catch (error: unknown) {
      console.error("Error uploading file:", error);
    }
  };

  // Download file handler
  const handleDownloadFile = (attachment: Attachment) => {
    try {
      // Decode base64 data
      const byteCharacters = atob(attachment.file_data);
      const byteNumbers = Array.from(
        { length: byteCharacters.length },
        (_, i) => byteCharacters.charCodeAt(i)
      );
      const byteArray = new Uint8Array(byteNumbers);

      // Create blob and download
      const blob = new Blob([byteArray], { type: attachment.file_type });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = attachment.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success(t("messages.downloadSuccess"));
    } catch (error) {
      console.error("Error downloading file:", error);
      toast.error(t("messages.downloadError"));
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    const files = Array.from(e.dataTransfer.files);
    const validFile = files.find(
      (file) =>
        file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        file.type === "application/pdf" ||
        file.type === "application/msword" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        file.name.endsWith(".xlsx") ||
        file.name.endsWith(".pdf") ||
        file.name.endsWith(".doc") ||
        file.name.endsWith(".docx")
    );

    if (validFile) {
      handleFileSelect(validFile);
    } else {
      toast.error(t("validation.invalidFile"));
    }
  };

  // Handler for track click
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [trackTransactionId, setTrackTransactionId] = useState<number | null>(
    null
  );
  const [activeOracleTab, setActiveOracleTab] = useState<"submit" | "journal">(
    "submit"
  );

  // Oracle Status API call
  const {
    data: oracleStatusData,
    isLoading: isLoadingOracleStatus,
    error: oracleStatusError,
    refetch: refetchOracleStatus,
  } = useGetOracleStatusQuery(trackTransactionId!, {
    skip: !trackTransactionId || !isTrackModalOpen,
  });

  // Status API call
  const {
    data: statusData,
    isLoading: isLoadingStatus,
    error: statusError,
  } = useGetTransferStatusQuery(statusTransactionId!, {
    skip: !statusTransactionId || !isStatusModalOpen,
  });

  const handleTrackClick = (row: TableRow) => {
    const transactionId = Number(row.id);
    setTrackTransactionId(null);
    setIsTrackModalOpen(true);
    // Set the transaction ID after modal is open to trigger fresh API call
    setTimeout(() => {
      setTrackTransactionId(transactionId);
    }, 100);
    console.log("Opening Oracle status for transaction:", transactionId);
  };

  const handleSearchChange = (text: string) => {
    setSearchQuery(text);
  };

  const handleSearchSubmit = (text: string) => {
    console.log("Search submitted:", text);
    // Implement search functionality
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleFilter = () => {
    console.log("Filter transfers");
    // Add your filter logic here
  };

  const handleEdit = (row: TableRow) => {
    const originalTransfer = row.original as TransferItem;
    console.log("Editing transfer:", originalTransfer); // Debug log

    setSelectedTransfer(originalTransfer);
    setIsEditMode(true);

    // Clear previous validation errors
    setValidationErrors({});

    // Populate form with existing data
    // Handle transaction_date - check if it matches one of our select options
    let transactionDate = originalTransfer.transaction_date || "";

    // If the transaction_date is a date string, try to extract month name
    if (
      transactionDate &&
      !accountOptions.some((option) => option.value === transactionDate)
    ) {
      try {
        const date = new Date(transactionDate);
        if (!isNaN(date.getTime())) {
          const monthNames = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          transactionDate = monthNames[date.getMonth()];
        }
      } catch {
        console.log("Could not parse date:", transactionDate);
        transactionDate = "";
      }
    }

    const isValidOption = accountOptions.some(
      (option) => option.value === transactionDate
    );
    const finalDateValue = isValidOption ? transactionDate : "";

    // Handle notes/reason - use notes field as HTML directly for rich text editor
    const notes = originalTransfer.notes || "";

    console.log("BEFORE setting form values:", {
      originalDate: originalTransfer.transaction_date,
      processedDate: transactionDate,
      isValidOption,
      finalDateValue,
      originalNotes: originalTransfer.notes,
      notes,
      currentTimePeriod: time_period,
      currentReason: reason,
    }); // Debug log

    // Set the values with explicit logging
    settime_period(finalDateValue);
    console.log("✅ Set time_period to:", finalDateValue);

    setreason(notes); // Use HTML directly
    console.log("✅ Set reason to:", notes);

    // Set budget control if available
    const budgetControl = originalTransfer.budget_control || "";
    setBudgetControl(budgetControl);
    console.log("✅ Set budget_control to:", budgetControl);

    console.log("AFTER setting form values:", {
      time_period_set: finalDateValue,
      reason_set: notes,
      budget_control_set: budgetControl,
    });

    // Trigger modal opening via useEffect after state updates
    setShouldOpenModal(true);
  };

  const handleDelete = async (row: TableRow) => {
    const transferStatus = row.status;

    // Check if transfer can be deleted
    if (transferStatus !== "pending") {
      toast.error(t("transfer.cannotDelete"));
      return;
    }

    try {
      await deleteTransfer(Number(row.id)).unwrap();
      toast.success(t("transfer.deleteSuccess"));
    } catch (error: unknown) {
      let errorMessage = "Failed to delete transfer";
      if (
        error &&
        typeof error === "object" &&
        "data" in error &&
        error.data &&
        typeof error.data === "object" &&
        "message" in error.data
      ) {
        errorMessage = String(error.data.message);
      } else if (error && typeof error === "object" && "message" in error) {
        errorMessage = String(error.message);
      }
      toast.error(errorMessage);
    }
  };

  const handleCreateRequest = () => {
    setIsEditMode(false);
    setSelectedTransfer(null);
    setValidationErrors({});

    // Clear form values
    settime_period("");
    setreason("");
    setBudgetControl("");
    setTransferType("");
    setAllocationSubType("");

    // Open modal after clearing values
    setIsCreateModalOpen(true);

    console.log("Creating new request - form cleared"); // Debug log
  };

  const handleCloseModal = () => {
    setIsCreateModalOpen(false);
    setIsEditMode(false);
    setSelectedTransfer(null);
    settime_period("");
    setreason("");
    setBudgetControl("");
    setTransferType("");
    setAllocationSubType("");
    setValidationErrors({});
    setShouldOpenModal(false); // Reset the modal trigger
  };

  const handleSave = async () => {
    // Clear previous validation errors
    setValidationErrors({});

    // Validation
    const errors: {
      time_period?: string;
      reason?: string;
      budget_control?: string;
      transfer_type?: string;
      allocation_sub_type?: string;
    } = {};

    if (!time_period.trim()) {
      errors.time_period = t("validation.selectTransactionDate");
    }

    if (!reason.trim()) {
      errors.reason = t("validation.enterNotes");
    }

    if (!budget_control.trim()) {
      errors.budget_control = t("validation.selectBudgetControl");
    }

    if (!transfer_type.trim()) {
      errors.transfer_type = t("validation.selectTransferType");
    }

    // Validate sub-type when "مخصصات" is selected
    if (transfer_type === "مخصصات" && !allocation_sub_type.trim()) {
      errors.allocation_sub_type = t("validation.selectAllocationSubType");
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    try {
      // Combine transfer_type with sub-type if "مخصصات" is selected
      const finalTransferType =
        transfer_type === "مخصصات"
          ? `${transfer_type}-${allocation_sub_type}`
          : transfer_type;

      // Use HTML directly from the rich text editor (no conversion needed)
      const transferData = {
        transaction_date: time_period,
        notes: reason, // reason already contains HTML from RichTextEditor
        type: "FAR", // Static as requested
        budget_control: budget_control,
        transfer_type: finalTransferType,
      };

      if (isEditMode && selectedTransfer) {
        // Update existing transfer
        await updateTransfer({
          id: selectedTransfer.transaction_id,
          body: transferData,
        }).unwrap();

        toast.success(t("transfer.updateSuccess"));
        console.log("Transfer updated successfully");
      } else {
        // Create new transfer
        await createTransfer(transferData).unwrap();

        toast.success(t("transfer.createSuccess"));
        console.log("Transfer created successfully");
      }

      handleCloseModal();
    } catch (error: unknown) {
      console.error("Error saving transfer:", error);
    }
  };

  const accountOptions: SelectOption[] = [
    // Previous Year (2024)
    { value: "1-24", label: "1-24" },
    // Current Year (2025)
    { value: "1-25", label: "1-25" },
    // Next Year (2026)
    // { value: "1-26", label: "1-26" },
  ];

  // Select options for budget control
  const budgetControlOptions: SelectOption[] = [
    { value: "سيولة", label: "سيولة" },
    { value: "تكاليف", label: "تكاليف" },
  ];

  // Select options for transfer type
  const transferTypeOptions: SelectOption[] = [
    { value: "داخلية", label: "داخلية" },
    { value: "خارجية", label: "خارجية" },
    { value: "مخصصات", label: "مخصصات" },
  ];

  // Sub-type options for "مخصصات" (Allocations)
  const allocationSubTypeOptions: SelectOption[] = [
    { value: "مراكز التكلفة", label: "مراكز التكلفة" },
    { value: "الموقع الجغرافي", label: "الموقع الجغرافي" },
  ];

  const handleChat = (row: TableRow) => {
    // Navigate to chat page with transaction/request ID
    navigate(`/app/chat/${row.id}`, { state: { txCode: row.code } });
  };

  // Handle export to PDF
  const handleExportToPdf = async (selectedIds: number[]) => {
    if (selectedIds.length === 0) {
      toast.error(t("messages.selectAtLeastOne"));
      return;
    }

    // Navigate to PDF view page
    const idsParam = selectedIds.join(",");
    navigate(`/app/transfer-pdf?ids=${idsParam}`);

    // Clear selection after navigation
    setSelectedRows(new Set());
  };

  return (
    <div>
      {/* Header with Create Button and Export Toggle */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold tracking-wide">
          {t("transfer.title")}
        </h1>
        <div className="flex gap-3">
          <button
            onClick={() => {
              setShowExportUI(!showExportUI);
              if (showExportUI) {
                // Clear selection when disabling export mode
                setSelectedRows(new Set());
              }
            }}
            className={`px-4 py-2 rounded-md transition-colors font-medium ${
              showExportUI
                ? "bg-red-500 hover:bg-red-600 text-white"
                : "bg-gray-200 hover:bg-gray-300 text-gray-700"
            }`}
          >
            {showExportUI ? t("common.cancel") : t("common.exportPDF")}
          </button>
          <button
            onClick={handleCreateRequest}
            className="px-4 py-2 bg-[#4E8476] hover:bg-[#3d6b5f] text-white rounded-md transition-colors font-medium"
          >
            {t("transfer.createTransfer")}
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-4 bg-white rounded-2xl mb-6">
        <SearchBar
          placeholder={t("common.searchPlaceholder")}
          value={searchQuery}
          onChange={handleSearchChange}
          onSubmit={handleSearchSubmit}
          debounce={250}
        />
      </div>

      {/* Transfer Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64 bg-white rounded-lg">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#4E8476]"></div>
          <span className="ml-2 text-gray-600">
            {t("messages.loadingTransfers")}
          </span>
        </div>
      ) : error ? (
        <div className="flex justify-center items-center h-64 bg-white rounded-lg">
          <div className="text-center">
            <div className="text-red-500 text-lg mb-2">⚠️</div>
            <p className="text-gray-600">
              {t("messages.errorLoadingTransfers")}
            </p>
            <button
              className="mt-2 px-4 py-2 bg-[#4E8476] text-white rounded hover:bg-[#4E8476]"
              onClick={() => window.location.reload()}
            >
              {t("common.retry")}
            </button>
          </div>
        </div>
      ) : transformedData.length === 0 ? (
        <div className="flex justify-center items-center h-64 bg-white rounded-lg">
          <div className="text-center">
            <div className="text-gray-400 text-2xl mb-2">📄</div>
            <p className="text-gray-600">{t("messages.noTransfers")}</p>
          </div>
        </div>
      ) : (
        <SharedTable
          title={t("transfer.title")}
          columns={transferColumns}
          data={transformedData}
          maxHeight="600px"
          className="shadow-lg"
          showPagination={true}
          currentPage={currentPage}
          onPageChange={handlePageChange}
          itemsPerPage={10}
          totalCount={transferResponse?.count}
          hasNext={!!transferResponse?.next}
          hasPrevious={!!transferResponse?.previous}
          showActions={true}
          showFooter={true}
          onEdit={handleEdit}
          transactions={true}
          onChat={handleChat}
          onDelete={handleDelete}
          onFilter={handleFilter}
          filterLabel={t("common.filterLabel")}
          showSelection={showExportUI}
          selectedRows={selectedRows}
          onSelectionChange={setSelectedRows}
          onExport={handleExportToPdf}
          showExportButton={showExportUI}
          exportButtonText={t("common.exportPDF")}
        />
      )}

      {/* Create/Edit Modal */}
      <SharedModal
        isOpen={isCreateModalOpen}
        onClose={handleCloseModal}
        title={
          isEditMode ? t("transfer.editTransfer") : t("transfer.createTransfer")
        }
        size="md"
      >
        <div className="p-4 space-y-4 overflow-y-auto max-h-[600px]">
          <div>
            <SharedSelect
              key={`budget-control-${
                isEditMode ? selectedTransfer?.transaction_id : "create"
              }`}
              title={t("tableColumns.budgetControl")}
              options={budgetControlOptions}
              value={budget_control}
              onChange={(value) => setBudgetControl(String(value))}
              placeholder={t("transfer.selectBudgetControl")}
              required
            />
            {validationErrors.budget_control && (
              <p className="mt-1 text-sm text-red-600">
                {validationErrors.budget_control}
              </p>
            )}
          </div>

          <div>
            <SharedSelect
              key={`transfer-type-${
                isEditMode ? selectedTransfer?.transaction_id : "create"
              }`}
              title={t("transfer.transferType")}
              options={transferTypeOptions}
              value={transfer_type}
              onChange={(value) => {
                setTransferType(String(value));
                // Clear sub-type when transfer type changes
                if (value !== "مخصصات") {
                  setAllocationSubType("");
                }
              }}
              placeholder={t("transfer.selectTransferType")}
              required
            />
            {validationErrors.transfer_type && (
              <p className="mt-1 text-sm text-red-600">
                {validationErrors.transfer_type}
              </p>
            )}
          </div>

          {/* Show sub-type select when "مخصصات" is selected */}
          {transfer_type === "مخصصات" && (
            <div>
              <SharedSelect
                key={`allocation-sub-type-${
                  isEditMode ? selectedTransfer?.transaction_id : "create"
                }`}
                title={t("transfer.allocationSubType")}
                options={allocationSubTypeOptions}
                value={allocation_sub_type}
                onChange={(value) => setAllocationSubType(String(value))}
                placeholder={t("transfer.selectAllocationSubType")}
                required
              />
              {validationErrors.allocation_sub_type && (
                <p className="mt-1 text-sm text-red-600">
                  {validationErrors.allocation_sub_type}
                </p>
              )}
            </div>
          )}

          <div>
            <SharedSelect
              key={`transaction-date-${
                isEditMode ? selectedTransfer?.transaction_id : "create"
              }`}
              title={t("tableColumns.transactionDate")}
              options={accountOptions}
              value={time_period}
              onChange={(value) => settime_period(String(value))}
              placeholder={t("transfer.selectTimePeriod")}
              required
            />
            {validationErrors.time_period && (
              <p className="mt-1 text-sm text-red-600">
                {validationErrors.time_period}
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-[#282828] mb-2">
              {t("common.notes")} *
            </label>
            <RichTextEditor
              value={reason}
              onChange={(value) => setreason(value)}
              placeholder={t("transfer.enterReason")}
              height={200}
              className={validationErrors.reason ? "border-red-500" : ""}
            />
            {validationErrors.reason && (
              <p className="mt-1 text-sm text-red-600">
                {validationErrors.reason}
              </p>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              onClick={handleCloseModal}
              disabled={isCreating || isUpdating}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {t("common.cancel")}
            </button>
            <button
              onClick={handleSave}
              disabled={
                isCreating ||
                isUpdating ||
                !budget_control.trim() ||
                !transfer_type.trim() ||
                !time_period.trim() ||
                !reason.trim() ||
                (transfer_type === "مخصصات" && !allocation_sub_type.trim())
              }
              className="px-4 py-2 text-sm font-medium text-white bg-[#4E8476] border border-[#4E8476] rounded-md hover:bg-[#4E8476] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {(isCreating || isUpdating) && (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              )}
              {isEditMode ? t("common.update") : t("common.create")}
            </button>
          </div>
        </div>
      </SharedModal>

      {/* Manage Attachments Modal */}
      <SharedModal
        isOpen={isAttachmentsModalOpen}
        onClose={() => setIsAttachmentsModalOpen(false)}
        title={t("common.manageAttachments")}
        size="lg"
      >
        <div className="p-4">
          {/* Upload section */}
          <div
            className={`w-full flex flex-col py-8 gap-4 items-center transition-colors mb-6 ${
              isDragOver
                ? "bg-[#9ce1de] border-2 border-dashed border-[#2d5147]"
                : "bg-[#F6F6F6]"
            } rounded-lg`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="rounded-full p-2">
              <svg
                width="50"
                height="50"
                viewBox="0 0 50 50"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M35.417 18.7542C39.9483 18.7794 42.4023 18.9803 44.0031 20.5811C45.8337 22.4117 45.8337 25.358 45.8337 31.2505V33.3339C45.8337 39.2264 45.8337 42.1727 44.0031 44.0033C42.1725 45.8339 39.2262 45.8339 33.3337 45.8339H16.667C10.7744 45.8339 7.82816 45.8339 5.99757 44.0033C4.16699 42.1727 4.16699 39.2264 4.16699 33.3339L4.16699 31.2505C4.16699 25.358 4.16699 22.4117 5.99757 20.5811C7.59837 18.9803 10.0524 18.7794 14.5837 18.7542"
                  stroke="#282828"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
                <path
                  d="M25 31.25L25 4.16666M25 4.16666L31.25 11.4583M25 4.16666L18.75 11.4583"
                  stroke="#282828"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div className="text-center">
              <div className="font-semibold text-base mb-1">
                {t("common.dragDrop")}{" "}
                <button
                  onClick={() =>
                    document.getElementById("file-upload")?.click()
                  }
                  className="text-[#4E8476] underline hover:text-blue-700 transition-colors"
                  disabled={isUploading}
                >
                  {t("common.browse")}
                </button>
              </div>
              <div className="text-xs text-[#757575] mb-2">
                {t("validation.supportedFormats")}
              </div>
              <input
                id="file-upload"
                type="file"
                accept=".xlsx,.pdf,.doc,.docx"
                className="hidden"
                disabled={isUploading}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    handleFileSelect(file);
                    e.target.value = ""; // Reset input
                  }
                }}
              />
            </div>
            {isUploading && (
              <div className="flex items-center gap-2 text-blue-600">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span className="text-sm">{t("messages.uploading")}</span>
              </div>
            )}
          </div>

          {/* Attachments list */}
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-800">
              {t("common.existingAttachments")}
            </h4>

            {isLoadingAttachments ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                <span className="ml-2 text-gray-600">
                  {t("messages.loadingAttachments")}
                </span>
              </div>
            ) : attachmentsData &&
              attachmentsData.attachments &&
              attachmentsData.attachments.length > 0 ? (
              <div className="space-y-2">
                {attachmentsData.attachments.map((attachment) => (
                  <div
                    key={attachment.attachment_id}
                    className="flex items-center justify-between gap-3 bg-white rounded-lg px-4 py-3 border border-gray-200"
                  >
                    <div className="flex items-center gap-2 flex-1">
                      <svg
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M16 2.5H8C4.5 2.5 3 4.5 3 7.5V17.5C3 20.5 4.5 22.5 8 22.5H16C19.5 22.5 21 20.5 21 17.5V7.5C21 4.5 19.5 2.5 16 2.5ZM8 12.75H12C12.41 12.75 12.75 13.09 12.75 13.5C12.75 13.91 12.41 14.25 12 14.25H8C7.59 14.25 7.25 13.91 7.25 13.5C7.25 13.09 7.59 12.75 8 12.75ZM16 18.25H8C7.59 18.25 7.25 17.91 7.25 17.5C7.25 17.09 7.59 16.75 8 16.75H16C16.41 16.75 16.75 17.09 16.75 17.5C16.75 17.91 16.41 18.25 16 18.25ZM18.5 9.75H16.5C14.98 9.75 13.75 8.52 13.75 7V5C13.75 4.59 14.09 4.25 14.5 4.25C14.91 4.25 15.25 4.59 15.25 5V7C15.25 7.69 15.81 8.25 16.5 8.25H18.5C18.91 8.25 19.25 8.59 19.25 9C19.25 9.41 18.91 9.75 18.5 9.75Z"
                          fill="#545454"
                        />
                      </svg>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-[#545454] truncate">
                          {attachment.file_name}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-[#545454]">
                      <span>{(attachment.file_size / 1024).toFixed(1)} KB</span>
                      <span>
                        {new Date(attachment.upload_date).toLocaleDateString()}
                      </span>
                      <button
                        className="bg-[#EEEEEE] p-1 rounded-md hover:bg-gray-300 transition-colors"
                        title="Download"
                        onClick={() => handleDownloadFile(attachment)}
                      >
                        <svg
                          width="16"
                          height="17"
                          viewBox="0 0 16 17"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M8.36902 11.5041C8.27429 11.6077 8.14038 11.6667 8 11.6667C7.85962 11.6667 7.72571 11.6077 7.63099 11.5041L4.96432 8.58738C4.77799 8.38358 4.79215 8.06732 4.99595 7.88099C5.19975 7.69465 5.51602 7.70881 5.70235 7.91262L7.5 9.8788V2.5C7.5 2.22386 7.72386 2 8 2C8.27614 2 8.5 2.22386 8.5 2.5V9.8788L10.2977 7.91262C10.484 7.70881 10.8003 7.69465 11.0041 7.88099C11.2079 8.06732 11.222 8.38358 11.0357 8.58738L8.36902 11.5041Z"
                            fill="#282828"
                          />
                          <path
                            d="M2.5 10.5C2.5 10.2239 2.27614 10 2 10C1.72386 10 1.5 10.2239 1.5 10.5V10.5366C1.49999 11.4483 1.49998 12.1832 1.57768 12.7612C1.65836 13.3612 1.83096 13.8665 2.23223 14.2678C2.63351 14.669 3.13876 14.8416 3.73883 14.9223C4.31681 15 5.05169 15 5.96342 15H10.0366C10.9483 15 11.6832 15 12.2612 14.9223C12.8612 14.8416 13.3665 14.669 13.7678 14.2678C14.169 13.8665 14.3416 13.3612 14.4223 12.7612C14.5 12.1832 14.5 11.4483 14.5 10.5366V10.5C14.5 10.2239 14.2761 10 14 10C13.7239 10 13.5 10.2239 13.5 10.5C13.5 11.4569 13.4989 12.1244 13.4312 12.6279C13.3655 13.1171 13.2452 13.3762 13.0607 13.5607C12.8762 13.7452 12.6171 13.8655 12.1279 13.9312C11.6244 13.9989 10.9569 14 10 14H6C5.04306 14 4.37565 13.9989 3.87208 13.9312C3.3829 13.8655 3.12385 13.7452 2.93934 13.5607C2.75483 13.3762 2.63453 13.1171 2.56877 12.6279C2.50106 12.1244 2.5 11.4569 2.5 10.5Z"
                            fill="#282828"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <div className="text-gray-400 text-2xl mb-2">📎</div>
                <p>{t("messages.noAttachments")}</p>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex justify-end gap-3 pt-6">
            <button
              onClick={() => setIsAttachmentsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 transition-colors"
            >
              {t("common.close")}
            </button>
          </div>
        </div>
      </SharedModal>
      {/* Oracle ERP Status Modal */}
      <SharedModal
        isOpen={isTrackModalOpen}
        onClose={() => {
          setIsTrackModalOpen(false);
          setTrackTransactionId(null);
          setActiveOracleTab("submit"); // Reset to default tab
        }}
        title={t("transfer.oracleStatus")}
        size="lg"
      >
        <div className="flex flex-col" style={{ maxHeight: "80vh" }}>
          {/* Tabs */}
          <div className="flex border-b border-gray-200 px-6 pt-4">
            <button
              onClick={() => setActiveOracleTab("submit")}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeOracleTab === "submit"
                  ? "border-[#4E8476] text-[#4E8476]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <div className="flex items-center gap-2">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                {t("oracle.submitSteps")}
              </div>
            </button>
            <button
              onClick={() => setActiveOracleTab("journal")}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeOracleTab === "journal"
                  ? "border-[#4E8476] text-[#4E8476]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <div className="flex items-center gap-2">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
                {t("oracle.approveRejectSteps")}
              </div>
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {isLoadingOracleStatus ? (
              <div className="space-y-6">
                {/* Loading Skeleton */}
                <div className="relative">
                  <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="relative flex items-start gap-4 pb-8 last:pb-0"
                    >
                      <div className="relative z-10 w-12 h-12 bg-gray-300 rounded-full animate-pulse"></div>
                      <div className="flex-1 pt-2 space-y-2">
                        <div className="h-4 bg-gray-300 rounded w-3/4 animate-pulse"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : oracleStatusError ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="text-red-500 text-4xl mb-4">⚠️</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {t("oracle.loadError")}
                </h3>
                <p className="text-sm text-gray-600 text-center max-w-md">
                  {t("oracle.loadErrorMessage")}
                </p>
              </div>
            ) : oracleStatusData ? (
              <div>
                {/* Submit Steps Tab Content */}
                {activeOracleTab === "submit" &&
                  (() => {
                    const submitGroup = oracleStatusData.action_groups.find(
                      (group) => group.action_type.toLowerCase() === "submit"
                    );

                    if (!submitGroup) {
                      return (
                        <div className="flex flex-col items-center justify-center py-12">
                          <div className="text-gray-400 text-4xl mb-4">📋</div>
                          <p className="text-sm text-gray-600">
                            {t("oracle.noSubmitSteps")}
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="relative">
                        {/* Vertical line */}
                        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-300"></div>

                        {submitGroup.steps.map((step, index) => {
                          // Check if this is an error/failed/warning status
                          const isErrorStatus = [
                            "error",
                            "failed",
                            "warning",
                          ].includes(step.status.toLowerCase());
                          const isSuccessStatus =
                            step.status.toLowerCase() === "success";

                          return (
                            <div
                              key={index}
                              className="relative flex items-start gap-4 pb-8 last:pb-0"
                            >
                              {/* Timeline dot with icon */}
                              <div
                                className={`relative z-10 flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center border-4 ${
                                  isSuccessStatus
                                    ? "bg-green-500 border-green-200"
                                    : isErrorStatus
                                    ? "bg-red-500 border-red-200"
                                    : "bg-gray-400 border-gray-200"
                                }`}
                              >
                                {isSuccessStatus ? (
                                  <svg
                                    className="w-6 h-6 text-white"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                  >
                                    <path
                                      fillRule="evenodd"
                                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                      clipRule="evenodd"
                                    />
                                  </svg>
                                ) : isErrorStatus ? (
                                  <svg
                                    className="w-6 h-6 text-white"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                  >
                                    <path
                                      fillRule="evenodd"
                                      d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                      clipRule="evenodd"
                                    />
                                  </svg>
                                ) : (
                                  <span className="text-white font-bold">
                                    {step.step_number}
                                  </span>
                                )}
                              </div>

                              {/* Step content */}
                              <div className="flex-1 min-w-0 pt-1">
                                <div className="flex items-center justify-between mb-1">
                                  <h4 className="text-sm font-semibold text-gray-900">
                                    {step.step_name}
                                  </h4>
                                  <span
                                    className={`text-xs font-medium px-2 py-1 rounded-full ${
                                      isSuccessStatus
                                        ? "bg-green-100 text-green-800"
                                        : isErrorStatus
                                        ? "bg-red-100 text-red-800"
                                        : "bg-gray-100 text-gray-800"
                                    }`}
                                  >
                                    {step.status}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">
                                  {step.message}
                                </p>
                                {(step.request_id ||
                                  step.document_id ||
                                  step.group_id) && (
                                  <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                                    {step.request_id && (
                                      <span>
                                        <span className="font-medium">
                                          {t("oracle.requestId")}:
                                        </span>{" "}
                                        {step.request_id}
                                      </span>
                                    )}
                                    {step.document_id && (
                                      <span>
                                        <span className="font-medium">
                                          {t("oracle.documentId")}:
                                        </span>{" "}
                                        {step.document_id}
                                      </span>
                                    )}
                                    {step.group_id && (
                                      <span>
                                        <span className="font-medium">
                                          {t("oracle.groupId")}:
                                        </span>{" "}
                                        {step.group_id}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}

                {/* Journal Steps Tab Content */}
                {activeOracleTab === "journal" &&
                  (() => {
                    const journalGroups = oracleStatusData.action_groups.filter(
                      (group) => group.action_type.toLowerCase() !== "submit"
                    );

                    if (journalGroups.length === 0) {
                      return (
                        <div className="flex flex-col items-center justify-center py-12">
                          <div className="text-gray-400 text-4xl mb-4">📋</div>
                          <p className="text-sm text-gray-600">
                            {t("oracle.noJournalSteps")}
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="space-y-8">
                        {journalGroups.map((group, groupIndex) => (
                          <div key={groupIndex}>
                            {/* Action Type Badge */}
                            <div className="flex items-center gap-3 mb-4">
                              <span className="text-xs font-bold text-[#4E8476] uppercase tracking-wider bg-[#4E8476]/10 px-3 py-1 rounded-full">
                                {group.action_type}
                              </span>
                              <div className="flex-1 h-px bg-gray-300"></div>
                            </div>

                            {/* Timeline for this action type */}
                            <div className="relative">
                              {/* Vertical line */}
                              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-300"></div>

                              {group.steps.map((step, index) => {
                                // Check if this is an error/failed/warning status
                                const isErrorStatus = [
                                  "error",
                                  "failed",
                                  "warning",
                                ].includes(step.status.toLowerCase());
                                const isSuccessStatus =
                                  step.status.toLowerCase() === "success";

                                return (
                                  <div
                                    key={index}
                                    className="relative flex items-start gap-4 pb-8 last:pb-0"
                                  >
                                    {/* Timeline dot with icon */}
                                    <div
                                      className={`relative z-10 flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center border-4 ${
                                        isSuccessStatus
                                          ? "bg-green-500 border-green-200"
                                          : isErrorStatus
                                          ? "bg-red-500 border-red-200"
                                          : "bg-gray-400 border-gray-200"
                                      }`}
                                    >
                                      {isSuccessStatus ? (
                                        <svg
                                          className="w-6 h-6 text-white"
                                          fill="currentColor"
                                          viewBox="0 0 20 20"
                                        >
                                          <path
                                            fillRule="evenodd"
                                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                            clipRule="evenodd"
                                          />
                                        </svg>
                                      ) : isErrorStatus ? (
                                        <svg
                                          className="w-6 h-6 text-white"
                                          fill="currentColor"
                                          viewBox="0 0 20 20"
                                        >
                                          <path
                                            fillRule="evenodd"
                                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                            clipRule="evenodd"
                                          />
                                        </svg>
                                      ) : (
                                        <span className="text-white font-bold">
                                          {step.step_number}
                                        </span>
                                      )}
                                    </div>

                                    {/* Step content */}
                                    <div className="flex-1 min-w-0 pt-1">
                                      <div className="flex items-center justify-between mb-1">
                                        <h4 className="text-sm font-semibold text-gray-900">
                                          {step.step_name}
                                        </h4>
                                        <span
                                          className={`text-xs font-medium px-2 py-1 rounded-full ${
                                            isSuccessStatus
                                              ? "bg-green-100 text-green-800"
                                              : isErrorStatus
                                              ? "bg-red-100 text-red-800"
                                              : "bg-gray-100 text-gray-800"
                                          }`}
                                        >
                                          {step.status}
                                        </span>
                                      </div>
                                      <p className="text-sm text-gray-600 mb-2">
                                        {step.message}
                                      </p>
                                      {(step.request_id ||
                                        step.document_id ||
                                        step.group_id) && (
                                        <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                                          {step.request_id && (
                                            <span>
                                              <span className="font-medium">
                                                {t("oracle.requestId")}:
                                              </span>{" "}
                                              {step.request_id}
                                            </span>
                                          )}
                                          {step.document_id && (
                                            <span>
                                              <span className="font-medium">
                                                {t("oracle.documentId")}:
                                              </span>{" "}
                                              {step.document_id}
                                            </span>
                                          )}
                                          {step.group_id && (
                                            <span>
                                              <span className="font-medium">
                                                {t("oracle.groupId")}:
                                              </span>{" "}
                                              {step.group_id}
                                            </span>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="text-gray-400 text-4xl mb-4">📋</div>
                <p className="text-sm text-gray-600">{t("oracle.noData")}</p>
              </div>
            )}
          </div>

          {/* Close Button */}
          <div className="flex justify-between px-6 py-4 border-t border-gray-200">
            <button
              onClick={() => {
                if (refetchOracleStatus) {
                  refetchOracleStatus();
                  toast.success(t("oracle.refreshing"));
                }
              }}
              disabled={isLoadingOracleStatus}
              className="px-4 py-2 text-sm font-medium text-[#4E8476] bg-[#4E8476]/10 border border-[#4E8476] rounded-md hover:bg-[#4E8476]/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isLoadingOracleStatus ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[#4E8476]"></div>
                  <span>{t("oracle.refreshing")}</span>
                </>
              ) : (
                <>
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                    />
                  </svg>
                  <span>{t("common.refresh")}</span>
                </>
              )}
            </button>
            <button
              onClick={() => {
                setIsTrackModalOpen(false);
                setTrackTransactionId(null);
                setActiveOracleTab("submit"); // Reset to default tab
              }}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 transition-colors"
            >
              {t("common.close")}
            </button>
          </div>
        </div>
      </SharedModal>

      {/* Status Pipeline Modal */}
      <SharedModal
        isOpen={isStatusModalOpen}
        onClose={() => {
          setIsStatusModalOpen(false);
          setStatusTransactionId(null); // Clear the transaction ID when closing
        }}
        title={t("transfer.statusPipeline")}
        size="lg"
      >
        <div className="p-6">
          {isLoadingStatus ? (
            <>
              {console.log('[MODAL] Rendering LOADING state')}
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="ml-2 text-gray-600">
                  {t("messages.loadingStatus")}
                </span>
              </div>
            </>
          ) : statusError ? (
            <>
              {console.log('[MODAL] Rendering ERROR state:', statusError)}
              <div className="flex justify-center items-center py-12">
                <div className="text-center">
                  <div className="text-red-500 text-lg mb-2">⚠️</div>
                  <p className="text-gray-600">
                    {t("messages.errorLoadingStatus")}
                  </p>
                </div>
              </div>
            </>
          ) : statusData ? (
            <div className="space-y-6">
              {/* Overall Status */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-600">Transfer Status:</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    statusData.transfer_status === 'approved' ? 'bg-green-100 text-green-800' :
                    statusData.transfer_status === 'rejected' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {statusData.transfer_status}
                  </span>
                </div>
              </div>

              {/* Workflows */}
              {statusData.workflows?.map((workflow) => (
                <div key={workflow.execution_order} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-md font-semibold text-gray-800">
                      {workflow.workflow_name}
                    </h4>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      workflow.workflow_status === 'approved' ? 'bg-green-100 text-green-800' :
                      workflow.workflow_status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {workflow.workflow_status}
                    </span>
                  </div>

                  <div className="relative">
                    {/* Timeline line */}
                    <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>

                    {workflow.stages?.map((stage) => (
                    <div
                      key={stage.order_index}
                      className="relative flex items-start space-x-4 pb-8 last:pb-0"
                    >
                      {/* Timeline dot */}
                      <div
                        className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full border-4 ${
                          stage.status === "approved" ||
                          stage.status === "active"
                            ? "bg-green-500 border-green-200"
                            : stage.status === "pending"
                            ? "bg-yellow-500 border-yellow-200"
                            : stage.status === "rejected"
                            ? "bg-red-500 border-red-200"
                            : "bg-[#4E8476] border-blue-200"
                        }`}
                      >
                        {stage.status === "approved" ||
                        stage.status === "active" ? (
                          <svg
                            className="w-6 h-6 text-white"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        ) : stage.status === "pending" ? (
                          <svg
                            className="w-6 h-6 text-white"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                              clipRule="evenodd"
                            />
                          </svg>
                        ) : stage.status === "rejected" ? (
                          <svg
                            className="w-6 h-6 text-white"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                              clipRule="evenodd"
                            />
                          </svg>
                        ) : (
                          <svg
                            className="w-6 h-6 text-white animate-spin"
                            viewBox="0 0 20 20"
                            fill="none"
                            role="status"
                            aria-label="In progress"
                          >
                            {/* faint full ring */}
                            <circle
                              cx="10"
                              cy="10"
                              r="8"
                              stroke="currentColor"
                              strokeWidth="2"
                              opacity="0.25"
                            />
                            {/* leading arc */}
                            <path
                              d="M10 2 A 8 8 0 0 1 18 10"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                            />
                          </svg>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="bg-white rounded-lg ">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="text-sm font-semibold text-gray-900">
                              {stage.name}
                            </h5>
                            <span className="text-xs text-gray-500">
                              {t("status.stage")} {stage.order_index}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-sm text-gray-600">
                            <span>
                              <span className="font-medium">
                                {t("status.decisionPolicy")}:
                              </span>{" "}
                              {stage.decision_policy}
                            </span>
                          </div>

                          {/* Stage Status Icon */}
                          <div className="flex items-center mt-3 text-sm">
                            {stage.status === "approved" ||
                            stage.status === "active" ? (
                              <div className="flex items-center text-green-600">
                                <svg
                                  className="w-4 h-4 mr-1"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                    clipRule="evenodd"
                                  />
                                </svg>
                                <span className="font-medium">
                                  {t("common.approved")}
                                </span>
                              </div>
                            ) : stage.status === "pending" ? (
                              <div className="flex items-center text-yellow-600">
                                <svg
                                  className="w-4 h-4 mr-1"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                                    clipRule="evenodd"
                                  />
                                </svg>
                                <span className="font-medium">
                                  {t("status.awaitingApproval")}
                                </span>
                              </div>
                            ) : stage.status === "rejected" ? (
                              <div className="flex items-center text-red-600">
                                <svg
                                  className="w-4 h-4 mr-1"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clipRule="evenodd"
                                  />
                                </svg>
                                <span className="font-medium">
                                  {t("common.rejected")}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center text-[#4E8476]">
                                <div className="w-4 h-4 bg-[#4E8476] rounded-full mr-1"></div>
                                <span className="font-medium">
                                  {t("status.inProgress")}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  </div>
                </div>
              ))}            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <div className="text-gray-400 text-2xl mb-2">📋</div>
              <p>{t("status.noData")}</p>
            </div>
          )}

          {/* Close button */}
          <div className="flex justify-end mt-6 pt-4  border-gray-200">
            <button
              onClick={() => {
                setIsStatusModalOpen(false);
                setStatusTransactionId(null); // Clear the transaction ID when closing
              }}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 transition-colors"
            >
              {t("common.close")}
            </button>
          </div>
        </div>
      </SharedModal>
    </div>
  );
}
